package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ReservationDAO {
	String R_CODE;
	String R_USER_CODE; //reservation table
	String R_G_CODE;
	String R_H_CODE;
	String R_TIME;   //��¥��
	String R_DATE;  //�ð���
	private Connection con; 
	private ResultSet rs; 
	
	public ReservationDAO() { 
		try { 
			String dbURL = "jdbc:mysql://localhost:3306/opendb?characterEncoding=UTF-8&serverTimezone=UTC"; 
			String dbID = "root";
			String dbPassword = "roqkf05"; 
			Class.forName("com.mysql.jdbc.Driver"); 
			con = DriverManager.getConnection(dbURL, dbID, dbPassword); 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		} // �α��� /* * -2: ���̵���� * -1: �������� * 0: ��й�ȣ Ʋ�� * 1: ���� */ 
	
/*	public int login(String userID, String userPassword) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT USER_PW FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery(); 
			if (rs.next()) { 
				return rs.getString(1).equals(userPassword) ? 1 : 0;
				} else { 
					return -2; 
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				return -1; 
				} 
		} // �ߺ����� Ȯ��
*/
	public boolean DATE_Check(String R_USER_CODE, String DATE, String TIME) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT * FROM reservation WHERE R_USER_CODE = ? and R_TIME =? and R_DATE =?"); 
			pst.setString(1, R_USER_CODE); 
			pst.setNString(2, DATE);
			pst.setNString(3,TIME);
			rs = pst.executeQuery();
			if (rs.next()) { 
					return false;
				} else { 
					return true;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
		
		
		
	} // ȸ������ /* * -1: �������� * 0: �̹� �����ϴ� ���̵� * 1: ���� */ 
	
	/*public int join(ReservationDAO reservationDAO) {
		if(!ID_Check(reservationDAO.getR_CODE()))
			return 0; 
		try {
			PreparedStatement pst = con.prepareStatement("INSERT INTO user VALUES (?,?,?,?,?)");
			pst.setString(1, "112"); 
			pst.setString(2, userDAO.getUSER_ID()); 
			pst.setString(3, userDAO.getUSER_PW()); 
			pst.setString(4, userDAO.getUSER_NAME());
			pst.setString(5, userDAO.getUSER_TEL());
			return pst.executeUpdate();
			} catch (Exception e) { 
				e.printStackTrace(); return -1; 
				}
		} // ���� ������ �������� 
		
			PreparedStatement pst = con.prepareStatement("SELECT * FROM reservation WHERE R_USER_CODE = '?' and R_TIME ='?'"); 
			pst.setString(1, R_USER_CODE); 
			pst.setNString(2, DATE);
	*/
	public boolean HorseCheck(String R_H_CODE,String DATE,String TIME) {
		try {
			PreparedStatement pst = con.prepareStatement("SELECT * FROM reservation WHERE R_H_CODE = ? and R_TIME =? and R_DATE =?");
			pst.setString(1, R_H_CODE); 
			pst.setNString(2, DATE);
			pst.setNString(3, TIME);

			rs = pst.executeQuery();
			if (rs.next()) { 
					return false;
				} else { 
					return true;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
		
		
		/*PreparedStatement pst = con.prepareStatement("SELECT R_TIME FROM reservation WHERE R_CODE = ?"); 
		pst.setString(1, R_CODE); 
		rs = pst.executeQuery();
		if (rs.next()) { 
			if(rs.getNString(1).equals(DATE)) {
				return false;
			}
			} else { 
				return true;
				} 
		} catch (Exception e) { 
			e.printStackTrace(); 
			} 
	return false;*/
	}
	public boolean ground_Check(String DATE,String TIME) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT * FROM reservation WHERE R_TIME =? and R_DATE =?"); 
			pst.setString(1, DATE); 
			pst.setString(2, TIME); 

			rs = pst.executeQuery();
			if (rs.next()) { 
				int count=0;
				do {
					count++;
				}while(rs.next()) ;
				System.out.println(count);

				if(count==4)
					return true;
				} else { 
					return false;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
		
		
		
	}
	public boolean reser_Full(String DATE) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT * FROM reservation WHERE R_TIME =?"); 
			pst.setString(1, DATE); 

			rs = pst.executeQuery();
			if (rs.next()) { 
				int count=0;
				
				do {
					count++;
				}while(rs.next()) ;
				System.out.println(count);

				if(count==16)
					return true;
				} else { 
					return false;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
		
		
		
	}
	
	public int reservation(ReservationDAO reservationDAO) {
		if(reser_Full(reservationDAO.getR_TIME())) return 6;
		if(!DATE_Check(reservationDAO.getR_USER_CODE(),reservationDAO.getR_TIME(),reservationDAO.getR_DATE())) return 0;
		if(ground_Check(reservationDAO.getR_TIME(),reservationDAO.getR_DATE())) return 4;

		if(!HorseCheck(reservationDAO.getR_H_CODE(),reservationDAO.getR_TIME(),reservationDAO.getR_DATE())) return 3;
		

		try {
			
			PreparedStatement pst1 =con.prepareStatement("SELECT MAX(R_CODE) FROM reservation");
			int max=0;
			rs = pst1.executeQuery();
			if(rs.next()) {
				max=rs.getInt(1);
				max=max+1;
			}
			PreparedStatement pst = con.prepareStatement("INSERT INTO reservation VALUES (?,?,?,?,?,?)");
			pst.setInt(1, max); 
			pst.setString(2, reservationDAO.getR_USER_CODE()); 
			pst.setString(3, reservationDAO.getR_G_CODE()); 
			pst.setString(4, reservationDAO.getR_H_CODE());
			pst.setString(5,reservationDAO.getR_TIME());
			pst.setNString(6, reservationDAO.getR_DATE());
			return pst.executeUpdate();
		}catch(Exception e){
			e.printStackTrace(); 
			return -1; 
		}
	}
	/*public String getUSERCODE(String USER_ID) {
		try {
			PreparedStatement pst = con.prepareStatement("SELECT USER_CODE FROM user WHERE USER_ID = ?"); 
			pst.setString(1,USER_ID);
			rs = pst.executeQuery();
			if(rs.next()) {
				return rs.getNString(1);
			}else 
				return null;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
			
			
			
			 * pst.setString(1, R_CODE); 
			rs = pst.executeQuery();
			if (rs.next()) { 
				if(rs.getNString(1).equals(DATE)) {
					return false;
				}
				} else { 
					return true;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
			 * 
		
	}*/
	
/*	public UserDAO getUser(String userID) { 
		try {
			PreparedStatement pst = con.prepareStatement("SELECT * FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery();
			if (rs.next()) { 
				UserDAO userDAO = new UserDAO(); 
				userDAO.setUSER_ID(rs.getString(1)); 
				userDAO.setUSER_PW(rs.getString(2)); 
				userDAO.setUSER_NAME(rs.getString(3)); 
				userDAO.setUSER_TEL(rs.getString(4)); 
				return userDAO; 
				} 
			} catch (Exception e) { 
				e.printStackTrace();
				} 
		return null; 
		}
	*/
	public ReservationDAO getReservation(String R_CODE) {
		try {
			PreparedStatement pst = con.prepareStatement("Select * FROM reservation WHERE R_CODE =?");
			pst.setString(1,R_CODE);
			rs=pst.executeQuery();
			if(rs.next()) {
				ReservationDAO reservationDAO = new ReservationDAO();
				reservationDAO.setR_CODE(rs.getNString(1));
				reservationDAO.setR_USER_CODE(rs.getNString(2));
				reservationDAO.setR_G_CODE(rs.getNString(3));
				reservationDAO.setR_H_CODE(rs.getNString(4));
				reservationDAO.setR_TIME(rs.getNString(5));
				return reservationDAO;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getR_CODE() {
		return R_CODE;
	}

	public void setR_CODE(String r_CODE) {
		R_CODE = r_CODE;
	}

	public String getR_USER_CODE() {
		return R_USER_CODE;
	}

	public void setR_USER_CODE(String r_USER_CODE) {
		R_USER_CODE = r_USER_CODE;
	}

	public String getR_G_CODE() {
		return R_G_CODE;
	}

	public void setR_G_CODE(String r_G_CODE) {
		R_G_CODE = r_G_CODE;
	}

	public String getR_H_CODE() {
		return R_H_CODE;
	}

	public void setR_H_CODE(String r_H_CODE) {
		R_H_CODE = r_H_CODE;
	}

	public String getR_TIME() {
		return R_TIME;
	}

	public void setR_TIME(String r_TIME) {
		R_TIME = r_TIME;
	}

	public String getR_DATE() {
		return R_DATE;
	}

	public void setR_DATE(String r_DATE) {
		R_DATE = r_DATE;
	}


}
