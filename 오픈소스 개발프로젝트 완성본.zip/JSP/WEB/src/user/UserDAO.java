package user; 

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.util.ArrayList; 
public class UserDAO { 
	String USER_ID; //user table
	String USER_PW;
	String USER_NAME;
	String USER_TEL;
	
	
	private Connection con; 
	private ResultSet rs; 
	
	public UserDAO() { 
		try { 
			String dbURL = "jdbc:mysql://localhost:3306/opendb?characterEncoding=UTF-8&serverTimezone=UTC"; 
			String dbID = "root";
			String dbPassword = "roqkf05"; 
			Class.forName("com.mysql.jdbc.Driver"); 
			con = DriverManager.getConnection(dbURL, dbID, dbPassword); 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		} // �α��� /* * -2: ���̵���� * -1: �������� * 0: ��й�ȣ Ʋ�� * 1: ���� */ 
	
	public int login(String userID, String userPassword) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT USER_PW FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery(); 
			if (rs.next()) { 
				return rs.getString(1).equals(userPassword) ? 1 : 0;
				} else { 
					return -2; 
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				return -1; 
				} 
		} // �ߺ����� Ȯ��
	public boolean ID_Check(String userID) { 
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT * FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery();
			if (rs.next()) { 
				return false; 
				} else { 
					return true;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return false;
	} // ȸ������ /* * -1: �������� * 0: �̹� �����ϴ� ���̵� * 1: ���� */ 
	public String PW_Check(String userID) {
		try { 
			PreparedStatement pst = con.prepareStatement("SELECT USER_PW FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery();
			if (rs.next()) { 
				return rs.getNString(1);
				} else { 
					return null;
					} 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		return null;
	}
	
	
	public int join(UserDAO userDAO) {
		if(!ID_Check(userDAO.getUSER_ID()))
			return 0; 
		try {
			PreparedStatement pst = con.prepareStatement("INSERT INTO user VALUES (?,?,?,?)");
			pst.setString(1, userDAO.getUSER_ID()); 
			pst.setString(2, userDAO.getUSER_PW()); 
			pst.setString(3, userDAO.getUSER_NAME());
			pst.setString(4, userDAO.getUSER_TEL());
			return pst.executeUpdate();
			} catch (Exception e) { 
				e.printStackTrace(); return -1; 
				}
		} // ���� ������ �������� 
	

	public UserDAO getUser(String userID) { 
		try {
			PreparedStatement pst = con.prepareStatement("SELECT * FROM user WHERE USER_ID = ?"); 
			pst.setString(1, userID); 
			rs = pst.executeQuery();
			if (rs.next()) { 
				UserDAO userDAO = new UserDAO(); 
				userDAO.setUSER_ID(rs.getString(1)); 
				userDAO.setUSER_PW(rs.getString(2)); 
				userDAO.setUSER_NAME(rs.getString(3)); 
				userDAO.setUSER_TEL(rs.getString(4)); 
				return userDAO; 
				} 
			} catch (Exception e) { 
				e.printStackTrace();
				} 
		return null; 
		}
	


	
	
	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}

	public String getUSER_PW() {
		return USER_PW;
	}

	public void setUSER_PW(String uSER_PW) {
		USER_PW = uSER_PW;
	}

	public String getUSER_NAME() {
		return USER_NAME;
	}

	public void setUSER_NAME(String uSER_NAME) {
		USER_NAME = uSER_NAME;
	}

	public String getUSER_TEL() {
		return USER_TEL;
	}

	public void setUSER_TEL(String uSER_TEL) {
		USER_TEL = uSER_TEL;
	}

}